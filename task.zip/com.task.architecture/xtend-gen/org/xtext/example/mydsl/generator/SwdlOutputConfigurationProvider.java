package org.xtext.example.mydsl.generator;

import java.util.HashSet;
import java.util.Set;
import org.eclipse.xtext.generator.IFileSystemAccess;
import org.eclipse.xtext.generator.IOutputConfigurationProvider;
import org.eclipse.xtext.generator.OutputConfiguration;

@SuppressWarnings("all")
public class SwdlOutputConfigurationProvider implements IOutputConfigurationProvider {
  @Override
  public Set<OutputConfiguration> getOutputConfigurations() {
    final OutputConfiguration output = new OutputConfiguration(IFileSystemAccess.DEFAULT_OUTPUT);
    output.setOutputDirectory("src-gen");
    output.setOverrideExistingResources(true);
    output.setCreateOutputDirectory(true);
    output.setCleanUpDerivedResources(true);
    output.setCanClearOutputDirectory(true);
    final HashSet<OutputConfiguration> set = new HashSet<OutputConfiguration>();
    set.add(output);
    return set;
  }
}
