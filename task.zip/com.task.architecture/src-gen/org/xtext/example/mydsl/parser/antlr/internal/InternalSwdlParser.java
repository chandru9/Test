package org.xtext.example.mydsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.mydsl.services.SwdlGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSwdlParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'SWComponent'", "'{'", "'}'", "'RequiredPort'", "'ProvidedPort'", "'Interface'", "'Element'", "':'", "'int'", "'string'", "'boolean'"
    };
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=5;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalSwdlParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSwdlParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSwdlParser.tokenNames; }
    public String getGrammarFileName() { return "InternalSwdl.g"; }



     	private SwdlGrammarAccess grammarAccess;

        public InternalSwdlParser(TokenStream input, SwdlGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected SwdlGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalSwdl.g:65:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalSwdl.g:65:46: (iv_ruleModel= ruleModel EOF )
            // InternalSwdl.g:66:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalSwdl.g:72:1: ruleModel returns [EObject current=null] : ( ( (lv_components_0_0= ruleSWComponent ) ) | ( (lv_interfaces_1_0= ruleInterface ) ) )* ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_components_0_0 = null;

        EObject lv_interfaces_1_0 = null;



        	enterRule();

        try {
            // InternalSwdl.g:78:2: ( ( ( (lv_components_0_0= ruleSWComponent ) ) | ( (lv_interfaces_1_0= ruleInterface ) ) )* )
            // InternalSwdl.g:79:2: ( ( (lv_components_0_0= ruleSWComponent ) ) | ( (lv_interfaces_1_0= ruleInterface ) ) )*
            {
            // InternalSwdl.g:79:2: ( ( (lv_components_0_0= ruleSWComponent ) ) | ( (lv_interfaces_1_0= ruleInterface ) ) )*
            loop1:
            do {
                int alt1=3;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11) ) {
                    alt1=1;
                }
                else if ( (LA1_0==16) ) {
                    alt1=2;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalSwdl.g:80:3: ( (lv_components_0_0= ruleSWComponent ) )
            	    {
            	    // InternalSwdl.g:80:3: ( (lv_components_0_0= ruleSWComponent ) )
            	    // InternalSwdl.g:81:4: (lv_components_0_0= ruleSWComponent )
            	    {
            	    // InternalSwdl.g:81:4: (lv_components_0_0= ruleSWComponent )
            	    // InternalSwdl.g:82:5: lv_components_0_0= ruleSWComponent
            	    {

            	    					newCompositeNode(grammarAccess.getModelAccess().getComponentsSWComponentParserRuleCall_0_0());
            	    				
            	    pushFollow(FOLLOW_3);
            	    lv_components_0_0=ruleSWComponent();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"components",
            	    						lv_components_0_0,
            	    						"org.xtext.example.mydsl.Swdl.SWComponent");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }


            	    }
            	    break;
            	case 2 :
            	    // InternalSwdl.g:100:3: ( (lv_interfaces_1_0= ruleInterface ) )
            	    {
            	    // InternalSwdl.g:100:3: ( (lv_interfaces_1_0= ruleInterface ) )
            	    // InternalSwdl.g:101:4: (lv_interfaces_1_0= ruleInterface )
            	    {
            	    // InternalSwdl.g:101:4: (lv_interfaces_1_0= ruleInterface )
            	    // InternalSwdl.g:102:5: lv_interfaces_1_0= ruleInterface
            	    {

            	    					newCompositeNode(grammarAccess.getModelAccess().getInterfacesInterfaceParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_3);
            	    lv_interfaces_1_0=ruleInterface();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"interfaces",
            	    						lv_interfaces_1_0,
            	    						"org.xtext.example.mydsl.Swdl.Interface");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleSWComponent"
    // InternalSwdl.g:123:1: entryRuleSWComponent returns [EObject current=null] : iv_ruleSWComponent= ruleSWComponent EOF ;
    public final EObject entryRuleSWComponent() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSWComponent = null;


        try {
            // InternalSwdl.g:123:52: (iv_ruleSWComponent= ruleSWComponent EOF )
            // InternalSwdl.g:124:2: iv_ruleSWComponent= ruleSWComponent EOF
            {
             newCompositeNode(grammarAccess.getSWComponentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSWComponent=ruleSWComponent();

            state._fsp--;

             current =iv_ruleSWComponent; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSWComponent"


    // $ANTLR start "ruleSWComponent"
    // InternalSwdl.g:130:1: ruleSWComponent returns [EObject current=null] : (otherlv_0= 'SWComponent' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_requiredPorts_3_0= ruleRequiredPort ) )* ( (lv_providedPorts_4_0= ruleProvidedPort ) )* otherlv_5= '}' ) ;
    public final EObject ruleSWComponent() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_5=null;
        EObject lv_requiredPorts_3_0 = null;

        EObject lv_providedPorts_4_0 = null;



        	enterRule();

        try {
            // InternalSwdl.g:136:2: ( (otherlv_0= 'SWComponent' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_requiredPorts_3_0= ruleRequiredPort ) )* ( (lv_providedPorts_4_0= ruleProvidedPort ) )* otherlv_5= '}' ) )
            // InternalSwdl.g:137:2: (otherlv_0= 'SWComponent' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_requiredPorts_3_0= ruleRequiredPort ) )* ( (lv_providedPorts_4_0= ruleProvidedPort ) )* otherlv_5= '}' )
            {
            // InternalSwdl.g:137:2: (otherlv_0= 'SWComponent' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_requiredPorts_3_0= ruleRequiredPort ) )* ( (lv_providedPorts_4_0= ruleProvidedPort ) )* otherlv_5= '}' )
            // InternalSwdl.g:138:3: otherlv_0= 'SWComponent' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_requiredPorts_3_0= ruleRequiredPort ) )* ( (lv_providedPorts_4_0= ruleProvidedPort ) )* otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,11,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getSWComponentAccess().getSWComponentKeyword_0());
            		
            // InternalSwdl.g:142:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSwdl.g:143:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSwdl.g:143:4: (lv_name_1_0= RULE_ID )
            // InternalSwdl.g:144:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getSWComponentAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSWComponentRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getSWComponentAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalSwdl.g:164:3: ( (lv_requiredPorts_3_0= ruleRequiredPort ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==14) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSwdl.g:165:4: (lv_requiredPorts_3_0= ruleRequiredPort )
            	    {
            	    // InternalSwdl.g:165:4: (lv_requiredPorts_3_0= ruleRequiredPort )
            	    // InternalSwdl.g:166:5: lv_requiredPorts_3_0= ruleRequiredPort
            	    {

            	    					newCompositeNode(grammarAccess.getSWComponentAccess().getRequiredPortsRequiredPortParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_6);
            	    lv_requiredPorts_3_0=ruleRequiredPort();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSWComponentRule());
            	    					}
            	    					add(
            	    						current,
            	    						"requiredPorts",
            	    						lv_requiredPorts_3_0,
            	    						"org.xtext.example.mydsl.Swdl.RequiredPort");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalSwdl.g:183:3: ( (lv_providedPorts_4_0= ruleProvidedPort ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==15) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalSwdl.g:184:4: (lv_providedPorts_4_0= ruleProvidedPort )
            	    {
            	    // InternalSwdl.g:184:4: (lv_providedPorts_4_0= ruleProvidedPort )
            	    // InternalSwdl.g:185:5: lv_providedPorts_4_0= ruleProvidedPort
            	    {

            	    					newCompositeNode(grammarAccess.getSWComponentAccess().getProvidedPortsProvidedPortParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_7);
            	    lv_providedPorts_4_0=ruleProvidedPort();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSWComponentRule());
            	    					}
            	    					add(
            	    						current,
            	    						"providedPorts",
            	    						lv_providedPorts_4_0,
            	    						"org.xtext.example.mydsl.Swdl.ProvidedPort");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            otherlv_5=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getSWComponentAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSWComponent"


    // $ANTLR start "entryRuleRequiredPort"
    // InternalSwdl.g:210:1: entryRuleRequiredPort returns [EObject current=null] : iv_ruleRequiredPort= ruleRequiredPort EOF ;
    public final EObject entryRuleRequiredPort() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRequiredPort = null;


        try {
            // InternalSwdl.g:210:53: (iv_ruleRequiredPort= ruleRequiredPort EOF )
            // InternalSwdl.g:211:2: iv_ruleRequiredPort= ruleRequiredPort EOF
            {
             newCompositeNode(grammarAccess.getRequiredPortRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRequiredPort=ruleRequiredPort();

            state._fsp--;

             current =iv_ruleRequiredPort; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRequiredPort"


    // $ANTLR start "ruleRequiredPort"
    // InternalSwdl.g:217:1: ruleRequiredPort returns [EObject current=null] : (otherlv_0= 'RequiredPort' ( (otherlv_1= RULE_ID ) ) ) ;
    public final EObject ruleRequiredPort() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;


        	enterRule();

        try {
            // InternalSwdl.g:223:2: ( (otherlv_0= 'RequiredPort' ( (otherlv_1= RULE_ID ) ) ) )
            // InternalSwdl.g:224:2: (otherlv_0= 'RequiredPort' ( (otherlv_1= RULE_ID ) ) )
            {
            // InternalSwdl.g:224:2: (otherlv_0= 'RequiredPort' ( (otherlv_1= RULE_ID ) ) )
            // InternalSwdl.g:225:3: otherlv_0= 'RequiredPort' ( (otherlv_1= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,14,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getRequiredPortAccess().getRequiredPortKeyword_0());
            		
            // InternalSwdl.g:229:3: ( (otherlv_1= RULE_ID ) )
            // InternalSwdl.g:230:4: (otherlv_1= RULE_ID )
            {
            // InternalSwdl.g:230:4: (otherlv_1= RULE_ID )
            // InternalSwdl.g:231:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRequiredPortRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(otherlv_1, grammarAccess.getRequiredPortAccess().getInterfaceInterfaceCrossReference_1_0());
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRequiredPort"


    // $ANTLR start "entryRuleProvidedPort"
    // InternalSwdl.g:246:1: entryRuleProvidedPort returns [EObject current=null] : iv_ruleProvidedPort= ruleProvidedPort EOF ;
    public final EObject entryRuleProvidedPort() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProvidedPort = null;


        try {
            // InternalSwdl.g:246:53: (iv_ruleProvidedPort= ruleProvidedPort EOF )
            // InternalSwdl.g:247:2: iv_ruleProvidedPort= ruleProvidedPort EOF
            {
             newCompositeNode(grammarAccess.getProvidedPortRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleProvidedPort=ruleProvidedPort();

            state._fsp--;

             current =iv_ruleProvidedPort; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProvidedPort"


    // $ANTLR start "ruleProvidedPort"
    // InternalSwdl.g:253:1: ruleProvidedPort returns [EObject current=null] : (otherlv_0= 'ProvidedPort' ( (otherlv_1= RULE_ID ) ) ) ;
    public final EObject ruleProvidedPort() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;


        	enterRule();

        try {
            // InternalSwdl.g:259:2: ( (otherlv_0= 'ProvidedPort' ( (otherlv_1= RULE_ID ) ) ) )
            // InternalSwdl.g:260:2: (otherlv_0= 'ProvidedPort' ( (otherlv_1= RULE_ID ) ) )
            {
            // InternalSwdl.g:260:2: (otherlv_0= 'ProvidedPort' ( (otherlv_1= RULE_ID ) ) )
            // InternalSwdl.g:261:3: otherlv_0= 'ProvidedPort' ( (otherlv_1= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,15,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getProvidedPortAccess().getProvidedPortKeyword_0());
            		
            // InternalSwdl.g:265:3: ( (otherlv_1= RULE_ID ) )
            // InternalSwdl.g:266:4: (otherlv_1= RULE_ID )
            {
            // InternalSwdl.g:266:4: (otherlv_1= RULE_ID )
            // InternalSwdl.g:267:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getProvidedPortRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(otherlv_1, grammarAccess.getProvidedPortAccess().getInterfaceInterfaceCrossReference_1_0());
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProvidedPort"


    // $ANTLR start "entryRuleInterface"
    // InternalSwdl.g:282:1: entryRuleInterface returns [EObject current=null] : iv_ruleInterface= ruleInterface EOF ;
    public final EObject entryRuleInterface() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInterface = null;


        try {
            // InternalSwdl.g:282:50: (iv_ruleInterface= ruleInterface EOF )
            // InternalSwdl.g:283:2: iv_ruleInterface= ruleInterface EOF
            {
             newCompositeNode(grammarAccess.getInterfaceRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInterface=ruleInterface();

            state._fsp--;

             current =iv_ruleInterface; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInterface"


    // $ANTLR start "ruleInterface"
    // InternalSwdl.g:289:1: ruleInterface returns [EObject current=null] : (otherlv_0= 'Interface' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleElement ) ) ( (lv_elements_4_0= ruleElement ) )* otherlv_5= '}' ) ;
    public final EObject ruleInterface() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_5=null;
        EObject lv_elements_3_0 = null;

        EObject lv_elements_4_0 = null;



        	enterRule();

        try {
            // InternalSwdl.g:295:2: ( (otherlv_0= 'Interface' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleElement ) ) ( (lv_elements_4_0= ruleElement ) )* otherlv_5= '}' ) )
            // InternalSwdl.g:296:2: (otherlv_0= 'Interface' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleElement ) ) ( (lv_elements_4_0= ruleElement ) )* otherlv_5= '}' )
            {
            // InternalSwdl.g:296:2: (otherlv_0= 'Interface' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleElement ) ) ( (lv_elements_4_0= ruleElement ) )* otherlv_5= '}' )
            // InternalSwdl.g:297:3: otherlv_0= 'Interface' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_elements_3_0= ruleElement ) ) ( (lv_elements_4_0= ruleElement ) )* otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,16,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getInterfaceAccess().getInterfaceKeyword_0());
            		
            // InternalSwdl.g:301:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSwdl.g:302:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSwdl.g:302:4: (lv_name_1_0= RULE_ID )
            // InternalSwdl.g:303:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getInterfaceAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInterfaceRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_8); 

            			newLeafNode(otherlv_2, grammarAccess.getInterfaceAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalSwdl.g:323:3: ( (lv_elements_3_0= ruleElement ) )
            // InternalSwdl.g:324:4: (lv_elements_3_0= ruleElement )
            {
            // InternalSwdl.g:324:4: (lv_elements_3_0= ruleElement )
            // InternalSwdl.g:325:5: lv_elements_3_0= ruleElement
            {

            					newCompositeNode(grammarAccess.getInterfaceAccess().getElementsElementParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_9);
            lv_elements_3_0=ruleElement();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getInterfaceRule());
            					}
            					add(
            						current,
            						"elements",
            						lv_elements_3_0,
            						"org.xtext.example.mydsl.Swdl.Element");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSwdl.g:342:3: ( (lv_elements_4_0= ruleElement ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==17) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalSwdl.g:343:4: (lv_elements_4_0= ruleElement )
            	    {
            	    // InternalSwdl.g:343:4: (lv_elements_4_0= ruleElement )
            	    // InternalSwdl.g:344:5: lv_elements_4_0= ruleElement
            	    {

            	    					newCompositeNode(grammarAccess.getInterfaceAccess().getElementsElementParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_9);
            	    lv_elements_4_0=ruleElement();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getInterfaceRule());
            	    					}
            	    					add(
            	    						current,
            	    						"elements",
            	    						lv_elements_4_0,
            	    						"org.xtext.example.mydsl.Swdl.Element");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            otherlv_5=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getInterfaceAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInterface"


    // $ANTLR start "entryRuleElement"
    // InternalSwdl.g:369:1: entryRuleElement returns [EObject current=null] : iv_ruleElement= ruleElement EOF ;
    public final EObject entryRuleElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElement = null;


        try {
            // InternalSwdl.g:369:48: (iv_ruleElement= ruleElement EOF )
            // InternalSwdl.g:370:2: iv_ruleElement= ruleElement EOF
            {
             newCompositeNode(grammarAccess.getElementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleElement=ruleElement();

            state._fsp--;

             current =iv_ruleElement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElement"


    // $ANTLR start "ruleElement"
    // InternalSwdl.g:376:1: ruleElement returns [EObject current=null] : (otherlv_0= 'Element' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleDataType ) ) ) ;
    public final EObject ruleElement() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Enumerator lv_type_3_0 = null;



        	enterRule();

        try {
            // InternalSwdl.g:382:2: ( (otherlv_0= 'Element' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleDataType ) ) ) )
            // InternalSwdl.g:383:2: (otherlv_0= 'Element' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleDataType ) ) )
            {
            // InternalSwdl.g:383:2: (otherlv_0= 'Element' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleDataType ) ) )
            // InternalSwdl.g:384:3: otherlv_0= 'Element' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= ':' ( (lv_type_3_0= ruleDataType ) )
            {
            otherlv_0=(Token)match(input,17,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getElementAccess().getElementKeyword_0());
            		
            // InternalSwdl.g:388:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSwdl.g:389:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSwdl.g:389:4: (lv_name_1_0= RULE_ID )
            // InternalSwdl.g:390:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_10); 

            					newLeafNode(lv_name_1_0, grammarAccess.getElementAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getElementRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,18,FOLLOW_11); 

            			newLeafNode(otherlv_2, grammarAccess.getElementAccess().getColonKeyword_2());
            		
            // InternalSwdl.g:410:3: ( (lv_type_3_0= ruleDataType ) )
            // InternalSwdl.g:411:4: (lv_type_3_0= ruleDataType )
            {
            // InternalSwdl.g:411:4: (lv_type_3_0= ruleDataType )
            // InternalSwdl.g:412:5: lv_type_3_0= ruleDataType
            {

            					newCompositeNode(grammarAccess.getElementAccess().getTypeDataTypeEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_type_3_0=ruleDataType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getElementRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_3_0,
            						"org.xtext.example.mydsl.Swdl.DataType");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElement"


    // $ANTLR start "ruleDataType"
    // InternalSwdl.g:433:1: ruleDataType returns [Enumerator current=null] : ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'string' ) | (enumLiteral_2= 'boolean' ) ) ;
    public final Enumerator ruleDataType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalSwdl.g:439:2: ( ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'string' ) | (enumLiteral_2= 'boolean' ) ) )
            // InternalSwdl.g:440:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'string' ) | (enumLiteral_2= 'boolean' ) )
            {
            // InternalSwdl.g:440:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'string' ) | (enumLiteral_2= 'boolean' ) )
            int alt5=3;
            switch ( input.LA(1) ) {
            case 19:
                {
                alt5=1;
                }
                break;
            case 20:
                {
                alt5=2;
                }
                break;
            case 21:
                {
                alt5=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // InternalSwdl.g:441:3: (enumLiteral_0= 'int' )
                    {
                    // InternalSwdl.g:441:3: (enumLiteral_0= 'int' )
                    // InternalSwdl.g:442:4: enumLiteral_0= 'int'
                    {
                    enumLiteral_0=(Token)match(input,19,FOLLOW_2); 

                    				current = grammarAccess.getDataTypeAccess().getIntEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getDataTypeAccess().getIntEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSwdl.g:449:3: (enumLiteral_1= 'string' )
                    {
                    // InternalSwdl.g:449:3: (enumLiteral_1= 'string' )
                    // InternalSwdl.g:450:4: enumLiteral_1= 'string'
                    {
                    enumLiteral_1=(Token)match(input,20,FOLLOW_2); 

                    				current = grammarAccess.getDataTypeAccess().getStringEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getDataTypeAccess().getStringEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSwdl.g:457:3: (enumLiteral_2= 'boolean' )
                    {
                    // InternalSwdl.g:457:3: (enumLiteral_2= 'boolean' )
                    // InternalSwdl.g:458:4: enumLiteral_2= 'boolean'
                    {
                    enumLiteral_2=(Token)match(input,21,FOLLOW_2); 

                    				current = grammarAccess.getDataTypeAccess().getBooleanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getDataTypeAccess().getBooleanEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000010802L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x000000000000E000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x000000000000A000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000022000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000380000L});

}