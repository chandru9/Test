package org.xtext.example.mydsl.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.example.mydsl.services.SwdlGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSwdlParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'int'", "'string'", "'boolean'", "'SWComponent'", "'{'", "'}'", "'RequiredPort'", "'ProvidedPort'", "'Interface'", "'Element'", "':'"
    };
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=5;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalSwdlParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSwdlParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSwdlParser.tokenNames; }
    public String getGrammarFileName() { return "InternalSwdl.g"; }


    	private SwdlGrammarAccess grammarAccess;

    	public void setGrammarAccess(SwdlGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleModel"
    // InternalSwdl.g:53:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // InternalSwdl.g:54:1: ( ruleModel EOF )
            // InternalSwdl.g:55:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalSwdl.g:62:1: ruleModel : ( ( rule__Model__Alternatives )* ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:66:2: ( ( ( rule__Model__Alternatives )* ) )
            // InternalSwdl.g:67:2: ( ( rule__Model__Alternatives )* )
            {
            // InternalSwdl.g:67:2: ( ( rule__Model__Alternatives )* )
            // InternalSwdl.g:68:3: ( rule__Model__Alternatives )*
            {
             before(grammarAccess.getModelAccess().getAlternatives()); 
            // InternalSwdl.g:69:3: ( rule__Model__Alternatives )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==14||LA1_0==19) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalSwdl.g:69:4: rule__Model__Alternatives
            	    {
            	    pushFollow(FOLLOW_3);
            	    rule__Model__Alternatives();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleSWComponent"
    // InternalSwdl.g:78:1: entryRuleSWComponent : ruleSWComponent EOF ;
    public final void entryRuleSWComponent() throws RecognitionException {
        try {
            // InternalSwdl.g:79:1: ( ruleSWComponent EOF )
            // InternalSwdl.g:80:1: ruleSWComponent EOF
            {
             before(grammarAccess.getSWComponentRule()); 
            pushFollow(FOLLOW_1);
            ruleSWComponent();

            state._fsp--;

             after(grammarAccess.getSWComponentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSWComponent"


    // $ANTLR start "ruleSWComponent"
    // InternalSwdl.g:87:1: ruleSWComponent : ( ( rule__SWComponent__Group__0 ) ) ;
    public final void ruleSWComponent() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:91:2: ( ( ( rule__SWComponent__Group__0 ) ) )
            // InternalSwdl.g:92:2: ( ( rule__SWComponent__Group__0 ) )
            {
            // InternalSwdl.g:92:2: ( ( rule__SWComponent__Group__0 ) )
            // InternalSwdl.g:93:3: ( rule__SWComponent__Group__0 )
            {
             before(grammarAccess.getSWComponentAccess().getGroup()); 
            // InternalSwdl.g:94:3: ( rule__SWComponent__Group__0 )
            // InternalSwdl.g:94:4: rule__SWComponent__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__SWComponent__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSWComponentAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSWComponent"


    // $ANTLR start "entryRuleRequiredPort"
    // InternalSwdl.g:103:1: entryRuleRequiredPort : ruleRequiredPort EOF ;
    public final void entryRuleRequiredPort() throws RecognitionException {
        try {
            // InternalSwdl.g:104:1: ( ruleRequiredPort EOF )
            // InternalSwdl.g:105:1: ruleRequiredPort EOF
            {
             before(grammarAccess.getRequiredPortRule()); 
            pushFollow(FOLLOW_1);
            ruleRequiredPort();

            state._fsp--;

             after(grammarAccess.getRequiredPortRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRequiredPort"


    // $ANTLR start "ruleRequiredPort"
    // InternalSwdl.g:112:1: ruleRequiredPort : ( ( rule__RequiredPort__Group__0 ) ) ;
    public final void ruleRequiredPort() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:116:2: ( ( ( rule__RequiredPort__Group__0 ) ) )
            // InternalSwdl.g:117:2: ( ( rule__RequiredPort__Group__0 ) )
            {
            // InternalSwdl.g:117:2: ( ( rule__RequiredPort__Group__0 ) )
            // InternalSwdl.g:118:3: ( rule__RequiredPort__Group__0 )
            {
             before(grammarAccess.getRequiredPortAccess().getGroup()); 
            // InternalSwdl.g:119:3: ( rule__RequiredPort__Group__0 )
            // InternalSwdl.g:119:4: rule__RequiredPort__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__RequiredPort__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRequiredPortAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRequiredPort"


    // $ANTLR start "entryRuleProvidedPort"
    // InternalSwdl.g:128:1: entryRuleProvidedPort : ruleProvidedPort EOF ;
    public final void entryRuleProvidedPort() throws RecognitionException {
        try {
            // InternalSwdl.g:129:1: ( ruleProvidedPort EOF )
            // InternalSwdl.g:130:1: ruleProvidedPort EOF
            {
             before(grammarAccess.getProvidedPortRule()); 
            pushFollow(FOLLOW_1);
            ruleProvidedPort();

            state._fsp--;

             after(grammarAccess.getProvidedPortRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleProvidedPort"


    // $ANTLR start "ruleProvidedPort"
    // InternalSwdl.g:137:1: ruleProvidedPort : ( ( rule__ProvidedPort__Group__0 ) ) ;
    public final void ruleProvidedPort() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:141:2: ( ( ( rule__ProvidedPort__Group__0 ) ) )
            // InternalSwdl.g:142:2: ( ( rule__ProvidedPort__Group__0 ) )
            {
            // InternalSwdl.g:142:2: ( ( rule__ProvidedPort__Group__0 ) )
            // InternalSwdl.g:143:3: ( rule__ProvidedPort__Group__0 )
            {
             before(grammarAccess.getProvidedPortAccess().getGroup()); 
            // InternalSwdl.g:144:3: ( rule__ProvidedPort__Group__0 )
            // InternalSwdl.g:144:4: rule__ProvidedPort__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ProvidedPort__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getProvidedPortAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleProvidedPort"


    // $ANTLR start "entryRuleInterface"
    // InternalSwdl.g:153:1: entryRuleInterface : ruleInterface EOF ;
    public final void entryRuleInterface() throws RecognitionException {
        try {
            // InternalSwdl.g:154:1: ( ruleInterface EOF )
            // InternalSwdl.g:155:1: ruleInterface EOF
            {
             before(grammarAccess.getInterfaceRule()); 
            pushFollow(FOLLOW_1);
            ruleInterface();

            state._fsp--;

             after(grammarAccess.getInterfaceRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInterface"


    // $ANTLR start "ruleInterface"
    // InternalSwdl.g:162:1: ruleInterface : ( ( rule__Interface__Group__0 ) ) ;
    public final void ruleInterface() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:166:2: ( ( ( rule__Interface__Group__0 ) ) )
            // InternalSwdl.g:167:2: ( ( rule__Interface__Group__0 ) )
            {
            // InternalSwdl.g:167:2: ( ( rule__Interface__Group__0 ) )
            // InternalSwdl.g:168:3: ( rule__Interface__Group__0 )
            {
             before(grammarAccess.getInterfaceAccess().getGroup()); 
            // InternalSwdl.g:169:3: ( rule__Interface__Group__0 )
            // InternalSwdl.g:169:4: rule__Interface__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Interface__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getInterfaceAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInterface"


    // $ANTLR start "entryRuleElement"
    // InternalSwdl.g:178:1: entryRuleElement : ruleElement EOF ;
    public final void entryRuleElement() throws RecognitionException {
        try {
            // InternalSwdl.g:179:1: ( ruleElement EOF )
            // InternalSwdl.g:180:1: ruleElement EOF
            {
             before(grammarAccess.getElementRule()); 
            pushFollow(FOLLOW_1);
            ruleElement();

            state._fsp--;

             after(grammarAccess.getElementRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleElement"


    // $ANTLR start "ruleElement"
    // InternalSwdl.g:187:1: ruleElement : ( ( rule__Element__Group__0 ) ) ;
    public final void ruleElement() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:191:2: ( ( ( rule__Element__Group__0 ) ) )
            // InternalSwdl.g:192:2: ( ( rule__Element__Group__0 ) )
            {
            // InternalSwdl.g:192:2: ( ( rule__Element__Group__0 ) )
            // InternalSwdl.g:193:3: ( rule__Element__Group__0 )
            {
             before(grammarAccess.getElementAccess().getGroup()); 
            // InternalSwdl.g:194:3: ( rule__Element__Group__0 )
            // InternalSwdl.g:194:4: rule__Element__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Element__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getElementAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleElement"


    // $ANTLR start "ruleDataType"
    // InternalSwdl.g:203:1: ruleDataType : ( ( rule__DataType__Alternatives ) ) ;
    public final void ruleDataType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:207:1: ( ( ( rule__DataType__Alternatives ) ) )
            // InternalSwdl.g:208:2: ( ( rule__DataType__Alternatives ) )
            {
            // InternalSwdl.g:208:2: ( ( rule__DataType__Alternatives ) )
            // InternalSwdl.g:209:3: ( rule__DataType__Alternatives )
            {
             before(grammarAccess.getDataTypeAccess().getAlternatives()); 
            // InternalSwdl.g:210:3: ( rule__DataType__Alternatives )
            // InternalSwdl.g:210:4: rule__DataType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__DataType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getDataTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "rule__Model__Alternatives"
    // InternalSwdl.g:218:1: rule__Model__Alternatives : ( ( ( rule__Model__ComponentsAssignment_0 ) ) | ( ( rule__Model__InterfacesAssignment_1 ) ) );
    public final void rule__Model__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:222:1: ( ( ( rule__Model__ComponentsAssignment_0 ) ) | ( ( rule__Model__InterfacesAssignment_1 ) ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==14) ) {
                alt2=1;
            }
            else if ( (LA2_0==19) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalSwdl.g:223:2: ( ( rule__Model__ComponentsAssignment_0 ) )
                    {
                    // InternalSwdl.g:223:2: ( ( rule__Model__ComponentsAssignment_0 ) )
                    // InternalSwdl.g:224:3: ( rule__Model__ComponentsAssignment_0 )
                    {
                     before(grammarAccess.getModelAccess().getComponentsAssignment_0()); 
                    // InternalSwdl.g:225:3: ( rule__Model__ComponentsAssignment_0 )
                    // InternalSwdl.g:225:4: rule__Model__ComponentsAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Model__ComponentsAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getModelAccess().getComponentsAssignment_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSwdl.g:229:2: ( ( rule__Model__InterfacesAssignment_1 ) )
                    {
                    // InternalSwdl.g:229:2: ( ( rule__Model__InterfacesAssignment_1 ) )
                    // InternalSwdl.g:230:3: ( rule__Model__InterfacesAssignment_1 )
                    {
                     before(grammarAccess.getModelAccess().getInterfacesAssignment_1()); 
                    // InternalSwdl.g:231:3: ( rule__Model__InterfacesAssignment_1 )
                    // InternalSwdl.g:231:4: rule__Model__InterfacesAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Model__InterfacesAssignment_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getModelAccess().getInterfacesAssignment_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Alternatives"


    // $ANTLR start "rule__DataType__Alternatives"
    // InternalSwdl.g:239:1: rule__DataType__Alternatives : ( ( ( 'int' ) ) | ( ( 'string' ) ) | ( ( 'boolean' ) ) );
    public final void rule__DataType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:243:1: ( ( ( 'int' ) ) | ( ( 'string' ) ) | ( ( 'boolean' ) ) )
            int alt3=3;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt3=1;
                }
                break;
            case 12:
                {
                alt3=2;
                }
                break;
            case 13:
                {
                alt3=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalSwdl.g:244:2: ( ( 'int' ) )
                    {
                    // InternalSwdl.g:244:2: ( ( 'int' ) )
                    // InternalSwdl.g:245:3: ( 'int' )
                    {
                     before(grammarAccess.getDataTypeAccess().getIntEnumLiteralDeclaration_0()); 
                    // InternalSwdl.g:246:3: ( 'int' )
                    // InternalSwdl.g:246:4: 'int'
                    {
                    match(input,11,FOLLOW_2); 

                    }

                     after(grammarAccess.getDataTypeAccess().getIntEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSwdl.g:250:2: ( ( 'string' ) )
                    {
                    // InternalSwdl.g:250:2: ( ( 'string' ) )
                    // InternalSwdl.g:251:3: ( 'string' )
                    {
                     before(grammarAccess.getDataTypeAccess().getStringEnumLiteralDeclaration_1()); 
                    // InternalSwdl.g:252:3: ( 'string' )
                    // InternalSwdl.g:252:4: 'string'
                    {
                    match(input,12,FOLLOW_2); 

                    }

                     after(grammarAccess.getDataTypeAccess().getStringEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSwdl.g:256:2: ( ( 'boolean' ) )
                    {
                    // InternalSwdl.g:256:2: ( ( 'boolean' ) )
                    // InternalSwdl.g:257:3: ( 'boolean' )
                    {
                     before(grammarAccess.getDataTypeAccess().getBooleanEnumLiteralDeclaration_2()); 
                    // InternalSwdl.g:258:3: ( 'boolean' )
                    // InternalSwdl.g:258:4: 'boolean'
                    {
                    match(input,13,FOLLOW_2); 

                    }

                     after(grammarAccess.getDataTypeAccess().getBooleanEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataType__Alternatives"


    // $ANTLR start "rule__SWComponent__Group__0"
    // InternalSwdl.g:266:1: rule__SWComponent__Group__0 : rule__SWComponent__Group__0__Impl rule__SWComponent__Group__1 ;
    public final void rule__SWComponent__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:270:1: ( rule__SWComponent__Group__0__Impl rule__SWComponent__Group__1 )
            // InternalSwdl.g:271:2: rule__SWComponent__Group__0__Impl rule__SWComponent__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__SWComponent__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SWComponent__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__Group__0"


    // $ANTLR start "rule__SWComponent__Group__0__Impl"
    // InternalSwdl.g:278:1: rule__SWComponent__Group__0__Impl : ( 'SWComponent' ) ;
    public final void rule__SWComponent__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:282:1: ( ( 'SWComponent' ) )
            // InternalSwdl.g:283:1: ( 'SWComponent' )
            {
            // InternalSwdl.g:283:1: ( 'SWComponent' )
            // InternalSwdl.g:284:2: 'SWComponent'
            {
             before(grammarAccess.getSWComponentAccess().getSWComponentKeyword_0()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getSWComponentAccess().getSWComponentKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__Group__0__Impl"


    // $ANTLR start "rule__SWComponent__Group__1"
    // InternalSwdl.g:293:1: rule__SWComponent__Group__1 : rule__SWComponent__Group__1__Impl rule__SWComponent__Group__2 ;
    public final void rule__SWComponent__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:297:1: ( rule__SWComponent__Group__1__Impl rule__SWComponent__Group__2 )
            // InternalSwdl.g:298:2: rule__SWComponent__Group__1__Impl rule__SWComponent__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__SWComponent__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SWComponent__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__Group__1"


    // $ANTLR start "rule__SWComponent__Group__1__Impl"
    // InternalSwdl.g:305:1: rule__SWComponent__Group__1__Impl : ( ( rule__SWComponent__NameAssignment_1 ) ) ;
    public final void rule__SWComponent__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:309:1: ( ( ( rule__SWComponent__NameAssignment_1 ) ) )
            // InternalSwdl.g:310:1: ( ( rule__SWComponent__NameAssignment_1 ) )
            {
            // InternalSwdl.g:310:1: ( ( rule__SWComponent__NameAssignment_1 ) )
            // InternalSwdl.g:311:2: ( rule__SWComponent__NameAssignment_1 )
            {
             before(grammarAccess.getSWComponentAccess().getNameAssignment_1()); 
            // InternalSwdl.g:312:2: ( rule__SWComponent__NameAssignment_1 )
            // InternalSwdl.g:312:3: rule__SWComponent__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__SWComponent__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getSWComponentAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__Group__1__Impl"


    // $ANTLR start "rule__SWComponent__Group__2"
    // InternalSwdl.g:320:1: rule__SWComponent__Group__2 : rule__SWComponent__Group__2__Impl rule__SWComponent__Group__3 ;
    public final void rule__SWComponent__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:324:1: ( rule__SWComponent__Group__2__Impl rule__SWComponent__Group__3 )
            // InternalSwdl.g:325:2: rule__SWComponent__Group__2__Impl rule__SWComponent__Group__3
            {
            pushFollow(FOLLOW_6);
            rule__SWComponent__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SWComponent__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__Group__2"


    // $ANTLR start "rule__SWComponent__Group__2__Impl"
    // InternalSwdl.g:332:1: rule__SWComponent__Group__2__Impl : ( '{' ) ;
    public final void rule__SWComponent__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:336:1: ( ( '{' ) )
            // InternalSwdl.g:337:1: ( '{' )
            {
            // InternalSwdl.g:337:1: ( '{' )
            // InternalSwdl.g:338:2: '{'
            {
             before(grammarAccess.getSWComponentAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getSWComponentAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__Group__2__Impl"


    // $ANTLR start "rule__SWComponent__Group__3"
    // InternalSwdl.g:347:1: rule__SWComponent__Group__3 : rule__SWComponent__Group__3__Impl rule__SWComponent__Group__4 ;
    public final void rule__SWComponent__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:351:1: ( rule__SWComponent__Group__3__Impl rule__SWComponent__Group__4 )
            // InternalSwdl.g:352:2: rule__SWComponent__Group__3__Impl rule__SWComponent__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__SWComponent__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SWComponent__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__Group__3"


    // $ANTLR start "rule__SWComponent__Group__3__Impl"
    // InternalSwdl.g:359:1: rule__SWComponent__Group__3__Impl : ( ( rule__SWComponent__RequiredPortsAssignment_3 )* ) ;
    public final void rule__SWComponent__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:363:1: ( ( ( rule__SWComponent__RequiredPortsAssignment_3 )* ) )
            // InternalSwdl.g:364:1: ( ( rule__SWComponent__RequiredPortsAssignment_3 )* )
            {
            // InternalSwdl.g:364:1: ( ( rule__SWComponent__RequiredPortsAssignment_3 )* )
            // InternalSwdl.g:365:2: ( rule__SWComponent__RequiredPortsAssignment_3 )*
            {
             before(grammarAccess.getSWComponentAccess().getRequiredPortsAssignment_3()); 
            // InternalSwdl.g:366:2: ( rule__SWComponent__RequiredPortsAssignment_3 )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==17) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalSwdl.g:366:3: rule__SWComponent__RequiredPortsAssignment_3
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__SWComponent__RequiredPortsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

             after(grammarAccess.getSWComponentAccess().getRequiredPortsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__Group__3__Impl"


    // $ANTLR start "rule__SWComponent__Group__4"
    // InternalSwdl.g:374:1: rule__SWComponent__Group__4 : rule__SWComponent__Group__4__Impl rule__SWComponent__Group__5 ;
    public final void rule__SWComponent__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:378:1: ( rule__SWComponent__Group__4__Impl rule__SWComponent__Group__5 )
            // InternalSwdl.g:379:2: rule__SWComponent__Group__4__Impl rule__SWComponent__Group__5
            {
            pushFollow(FOLLOW_6);
            rule__SWComponent__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SWComponent__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__Group__4"


    // $ANTLR start "rule__SWComponent__Group__4__Impl"
    // InternalSwdl.g:386:1: rule__SWComponent__Group__4__Impl : ( ( rule__SWComponent__ProvidedPortsAssignment_4 )* ) ;
    public final void rule__SWComponent__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:390:1: ( ( ( rule__SWComponent__ProvidedPortsAssignment_4 )* ) )
            // InternalSwdl.g:391:1: ( ( rule__SWComponent__ProvidedPortsAssignment_4 )* )
            {
            // InternalSwdl.g:391:1: ( ( rule__SWComponent__ProvidedPortsAssignment_4 )* )
            // InternalSwdl.g:392:2: ( rule__SWComponent__ProvidedPortsAssignment_4 )*
            {
             before(grammarAccess.getSWComponentAccess().getProvidedPortsAssignment_4()); 
            // InternalSwdl.g:393:2: ( rule__SWComponent__ProvidedPortsAssignment_4 )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==18) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalSwdl.g:393:3: rule__SWComponent__ProvidedPortsAssignment_4
            	    {
            	    pushFollow(FOLLOW_8);
            	    rule__SWComponent__ProvidedPortsAssignment_4();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

             after(grammarAccess.getSWComponentAccess().getProvidedPortsAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__Group__4__Impl"


    // $ANTLR start "rule__SWComponent__Group__5"
    // InternalSwdl.g:401:1: rule__SWComponent__Group__5 : rule__SWComponent__Group__5__Impl ;
    public final void rule__SWComponent__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:405:1: ( rule__SWComponent__Group__5__Impl )
            // InternalSwdl.g:406:2: rule__SWComponent__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SWComponent__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__Group__5"


    // $ANTLR start "rule__SWComponent__Group__5__Impl"
    // InternalSwdl.g:412:1: rule__SWComponent__Group__5__Impl : ( '}' ) ;
    public final void rule__SWComponent__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:416:1: ( ( '}' ) )
            // InternalSwdl.g:417:1: ( '}' )
            {
            // InternalSwdl.g:417:1: ( '}' )
            // InternalSwdl.g:418:2: '}'
            {
             before(grammarAccess.getSWComponentAccess().getRightCurlyBracketKeyword_5()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getSWComponentAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__Group__5__Impl"


    // $ANTLR start "rule__RequiredPort__Group__0"
    // InternalSwdl.g:428:1: rule__RequiredPort__Group__0 : rule__RequiredPort__Group__0__Impl rule__RequiredPort__Group__1 ;
    public final void rule__RequiredPort__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:432:1: ( rule__RequiredPort__Group__0__Impl rule__RequiredPort__Group__1 )
            // InternalSwdl.g:433:2: rule__RequiredPort__Group__0__Impl rule__RequiredPort__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__RequiredPort__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RequiredPort__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RequiredPort__Group__0"


    // $ANTLR start "rule__RequiredPort__Group__0__Impl"
    // InternalSwdl.g:440:1: rule__RequiredPort__Group__0__Impl : ( 'RequiredPort' ) ;
    public final void rule__RequiredPort__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:444:1: ( ( 'RequiredPort' ) )
            // InternalSwdl.g:445:1: ( 'RequiredPort' )
            {
            // InternalSwdl.g:445:1: ( 'RequiredPort' )
            // InternalSwdl.g:446:2: 'RequiredPort'
            {
             before(grammarAccess.getRequiredPortAccess().getRequiredPortKeyword_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getRequiredPortAccess().getRequiredPortKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RequiredPort__Group__0__Impl"


    // $ANTLR start "rule__RequiredPort__Group__1"
    // InternalSwdl.g:455:1: rule__RequiredPort__Group__1 : rule__RequiredPort__Group__1__Impl ;
    public final void rule__RequiredPort__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:459:1: ( rule__RequiredPort__Group__1__Impl )
            // InternalSwdl.g:460:2: rule__RequiredPort__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__RequiredPort__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RequiredPort__Group__1"


    // $ANTLR start "rule__RequiredPort__Group__1__Impl"
    // InternalSwdl.g:466:1: rule__RequiredPort__Group__1__Impl : ( ( rule__RequiredPort__InterfaceAssignment_1 ) ) ;
    public final void rule__RequiredPort__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:470:1: ( ( ( rule__RequiredPort__InterfaceAssignment_1 ) ) )
            // InternalSwdl.g:471:1: ( ( rule__RequiredPort__InterfaceAssignment_1 ) )
            {
            // InternalSwdl.g:471:1: ( ( rule__RequiredPort__InterfaceAssignment_1 ) )
            // InternalSwdl.g:472:2: ( rule__RequiredPort__InterfaceAssignment_1 )
            {
             before(grammarAccess.getRequiredPortAccess().getInterfaceAssignment_1()); 
            // InternalSwdl.g:473:2: ( rule__RequiredPort__InterfaceAssignment_1 )
            // InternalSwdl.g:473:3: rule__RequiredPort__InterfaceAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__RequiredPort__InterfaceAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getRequiredPortAccess().getInterfaceAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RequiredPort__Group__1__Impl"


    // $ANTLR start "rule__ProvidedPort__Group__0"
    // InternalSwdl.g:482:1: rule__ProvidedPort__Group__0 : rule__ProvidedPort__Group__0__Impl rule__ProvidedPort__Group__1 ;
    public final void rule__ProvidedPort__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:486:1: ( rule__ProvidedPort__Group__0__Impl rule__ProvidedPort__Group__1 )
            // InternalSwdl.g:487:2: rule__ProvidedPort__Group__0__Impl rule__ProvidedPort__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__ProvidedPort__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ProvidedPort__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProvidedPort__Group__0"


    // $ANTLR start "rule__ProvidedPort__Group__0__Impl"
    // InternalSwdl.g:494:1: rule__ProvidedPort__Group__0__Impl : ( 'ProvidedPort' ) ;
    public final void rule__ProvidedPort__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:498:1: ( ( 'ProvidedPort' ) )
            // InternalSwdl.g:499:1: ( 'ProvidedPort' )
            {
            // InternalSwdl.g:499:1: ( 'ProvidedPort' )
            // InternalSwdl.g:500:2: 'ProvidedPort'
            {
             before(grammarAccess.getProvidedPortAccess().getProvidedPortKeyword_0()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getProvidedPortAccess().getProvidedPortKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProvidedPort__Group__0__Impl"


    // $ANTLR start "rule__ProvidedPort__Group__1"
    // InternalSwdl.g:509:1: rule__ProvidedPort__Group__1 : rule__ProvidedPort__Group__1__Impl ;
    public final void rule__ProvidedPort__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:513:1: ( rule__ProvidedPort__Group__1__Impl )
            // InternalSwdl.g:514:2: rule__ProvidedPort__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ProvidedPort__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProvidedPort__Group__1"


    // $ANTLR start "rule__ProvidedPort__Group__1__Impl"
    // InternalSwdl.g:520:1: rule__ProvidedPort__Group__1__Impl : ( ( rule__ProvidedPort__InterfaceAssignment_1 ) ) ;
    public final void rule__ProvidedPort__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:524:1: ( ( ( rule__ProvidedPort__InterfaceAssignment_1 ) ) )
            // InternalSwdl.g:525:1: ( ( rule__ProvidedPort__InterfaceAssignment_1 ) )
            {
            // InternalSwdl.g:525:1: ( ( rule__ProvidedPort__InterfaceAssignment_1 ) )
            // InternalSwdl.g:526:2: ( rule__ProvidedPort__InterfaceAssignment_1 )
            {
             before(grammarAccess.getProvidedPortAccess().getInterfaceAssignment_1()); 
            // InternalSwdl.g:527:2: ( rule__ProvidedPort__InterfaceAssignment_1 )
            // InternalSwdl.g:527:3: rule__ProvidedPort__InterfaceAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ProvidedPort__InterfaceAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getProvidedPortAccess().getInterfaceAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProvidedPort__Group__1__Impl"


    // $ANTLR start "rule__Interface__Group__0"
    // InternalSwdl.g:536:1: rule__Interface__Group__0 : rule__Interface__Group__0__Impl rule__Interface__Group__1 ;
    public final void rule__Interface__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:540:1: ( rule__Interface__Group__0__Impl rule__Interface__Group__1 )
            // InternalSwdl.g:541:2: rule__Interface__Group__0__Impl rule__Interface__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Interface__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Interface__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__0"


    // $ANTLR start "rule__Interface__Group__0__Impl"
    // InternalSwdl.g:548:1: rule__Interface__Group__0__Impl : ( 'Interface' ) ;
    public final void rule__Interface__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:552:1: ( ( 'Interface' ) )
            // InternalSwdl.g:553:1: ( 'Interface' )
            {
            // InternalSwdl.g:553:1: ( 'Interface' )
            // InternalSwdl.g:554:2: 'Interface'
            {
             before(grammarAccess.getInterfaceAccess().getInterfaceKeyword_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getInterfaceAccess().getInterfaceKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__0__Impl"


    // $ANTLR start "rule__Interface__Group__1"
    // InternalSwdl.g:563:1: rule__Interface__Group__1 : rule__Interface__Group__1__Impl rule__Interface__Group__2 ;
    public final void rule__Interface__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:567:1: ( rule__Interface__Group__1__Impl rule__Interface__Group__2 )
            // InternalSwdl.g:568:2: rule__Interface__Group__1__Impl rule__Interface__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Interface__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Interface__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__1"


    // $ANTLR start "rule__Interface__Group__1__Impl"
    // InternalSwdl.g:575:1: rule__Interface__Group__1__Impl : ( ( rule__Interface__NameAssignment_1 ) ) ;
    public final void rule__Interface__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:579:1: ( ( ( rule__Interface__NameAssignment_1 ) ) )
            // InternalSwdl.g:580:1: ( ( rule__Interface__NameAssignment_1 ) )
            {
            // InternalSwdl.g:580:1: ( ( rule__Interface__NameAssignment_1 ) )
            // InternalSwdl.g:581:2: ( rule__Interface__NameAssignment_1 )
            {
             before(grammarAccess.getInterfaceAccess().getNameAssignment_1()); 
            // InternalSwdl.g:582:2: ( rule__Interface__NameAssignment_1 )
            // InternalSwdl.g:582:3: rule__Interface__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Interface__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getInterfaceAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__1__Impl"


    // $ANTLR start "rule__Interface__Group__2"
    // InternalSwdl.g:590:1: rule__Interface__Group__2 : rule__Interface__Group__2__Impl rule__Interface__Group__3 ;
    public final void rule__Interface__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:594:1: ( rule__Interface__Group__2__Impl rule__Interface__Group__3 )
            // InternalSwdl.g:595:2: rule__Interface__Group__2__Impl rule__Interface__Group__3
            {
            pushFollow(FOLLOW_9);
            rule__Interface__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Interface__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__2"


    // $ANTLR start "rule__Interface__Group__2__Impl"
    // InternalSwdl.g:602:1: rule__Interface__Group__2__Impl : ( '{' ) ;
    public final void rule__Interface__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:606:1: ( ( '{' ) )
            // InternalSwdl.g:607:1: ( '{' )
            {
            // InternalSwdl.g:607:1: ( '{' )
            // InternalSwdl.g:608:2: '{'
            {
             before(grammarAccess.getInterfaceAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getInterfaceAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__2__Impl"


    // $ANTLR start "rule__Interface__Group__3"
    // InternalSwdl.g:617:1: rule__Interface__Group__3 : rule__Interface__Group__3__Impl rule__Interface__Group__4 ;
    public final void rule__Interface__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:621:1: ( rule__Interface__Group__3__Impl rule__Interface__Group__4 )
            // InternalSwdl.g:622:2: rule__Interface__Group__3__Impl rule__Interface__Group__4
            {
            pushFollow(FOLLOW_10);
            rule__Interface__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Interface__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__3"


    // $ANTLR start "rule__Interface__Group__3__Impl"
    // InternalSwdl.g:629:1: rule__Interface__Group__3__Impl : ( ( rule__Interface__ElementsAssignment_3 ) ) ;
    public final void rule__Interface__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:633:1: ( ( ( rule__Interface__ElementsAssignment_3 ) ) )
            // InternalSwdl.g:634:1: ( ( rule__Interface__ElementsAssignment_3 ) )
            {
            // InternalSwdl.g:634:1: ( ( rule__Interface__ElementsAssignment_3 ) )
            // InternalSwdl.g:635:2: ( rule__Interface__ElementsAssignment_3 )
            {
             before(grammarAccess.getInterfaceAccess().getElementsAssignment_3()); 
            // InternalSwdl.g:636:2: ( rule__Interface__ElementsAssignment_3 )
            // InternalSwdl.g:636:3: rule__Interface__ElementsAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Interface__ElementsAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getInterfaceAccess().getElementsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__3__Impl"


    // $ANTLR start "rule__Interface__Group__4"
    // InternalSwdl.g:644:1: rule__Interface__Group__4 : rule__Interface__Group__4__Impl rule__Interface__Group__5 ;
    public final void rule__Interface__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:648:1: ( rule__Interface__Group__4__Impl rule__Interface__Group__5 )
            // InternalSwdl.g:649:2: rule__Interface__Group__4__Impl rule__Interface__Group__5
            {
            pushFollow(FOLLOW_10);
            rule__Interface__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Interface__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__4"


    // $ANTLR start "rule__Interface__Group__4__Impl"
    // InternalSwdl.g:656:1: rule__Interface__Group__4__Impl : ( ( rule__Interface__ElementsAssignment_4 )* ) ;
    public final void rule__Interface__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:660:1: ( ( ( rule__Interface__ElementsAssignment_4 )* ) )
            // InternalSwdl.g:661:1: ( ( rule__Interface__ElementsAssignment_4 )* )
            {
            // InternalSwdl.g:661:1: ( ( rule__Interface__ElementsAssignment_4 )* )
            // InternalSwdl.g:662:2: ( rule__Interface__ElementsAssignment_4 )*
            {
             before(grammarAccess.getInterfaceAccess().getElementsAssignment_4()); 
            // InternalSwdl.g:663:2: ( rule__Interface__ElementsAssignment_4 )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==20) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalSwdl.g:663:3: rule__Interface__ElementsAssignment_4
            	    {
            	    pushFollow(FOLLOW_11);
            	    rule__Interface__ElementsAssignment_4();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

             after(grammarAccess.getInterfaceAccess().getElementsAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__4__Impl"


    // $ANTLR start "rule__Interface__Group__5"
    // InternalSwdl.g:671:1: rule__Interface__Group__5 : rule__Interface__Group__5__Impl ;
    public final void rule__Interface__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:675:1: ( rule__Interface__Group__5__Impl )
            // InternalSwdl.g:676:2: rule__Interface__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Interface__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__5"


    // $ANTLR start "rule__Interface__Group__5__Impl"
    // InternalSwdl.g:682:1: rule__Interface__Group__5__Impl : ( '}' ) ;
    public final void rule__Interface__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:686:1: ( ( '}' ) )
            // InternalSwdl.g:687:1: ( '}' )
            {
            // InternalSwdl.g:687:1: ( '}' )
            // InternalSwdl.g:688:2: '}'
            {
             before(grammarAccess.getInterfaceAccess().getRightCurlyBracketKeyword_5()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getInterfaceAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__5__Impl"


    // $ANTLR start "rule__Element__Group__0"
    // InternalSwdl.g:698:1: rule__Element__Group__0 : rule__Element__Group__0__Impl rule__Element__Group__1 ;
    public final void rule__Element__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:702:1: ( rule__Element__Group__0__Impl rule__Element__Group__1 )
            // InternalSwdl.g:703:2: rule__Element__Group__0__Impl rule__Element__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Element__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Element__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group__0"


    // $ANTLR start "rule__Element__Group__0__Impl"
    // InternalSwdl.g:710:1: rule__Element__Group__0__Impl : ( 'Element' ) ;
    public final void rule__Element__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:714:1: ( ( 'Element' ) )
            // InternalSwdl.g:715:1: ( 'Element' )
            {
            // InternalSwdl.g:715:1: ( 'Element' )
            // InternalSwdl.g:716:2: 'Element'
            {
             before(grammarAccess.getElementAccess().getElementKeyword_0()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getElementAccess().getElementKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group__0__Impl"


    // $ANTLR start "rule__Element__Group__1"
    // InternalSwdl.g:725:1: rule__Element__Group__1 : rule__Element__Group__1__Impl rule__Element__Group__2 ;
    public final void rule__Element__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:729:1: ( rule__Element__Group__1__Impl rule__Element__Group__2 )
            // InternalSwdl.g:730:2: rule__Element__Group__1__Impl rule__Element__Group__2
            {
            pushFollow(FOLLOW_12);
            rule__Element__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Element__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group__1"


    // $ANTLR start "rule__Element__Group__1__Impl"
    // InternalSwdl.g:737:1: rule__Element__Group__1__Impl : ( ( rule__Element__NameAssignment_1 ) ) ;
    public final void rule__Element__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:741:1: ( ( ( rule__Element__NameAssignment_1 ) ) )
            // InternalSwdl.g:742:1: ( ( rule__Element__NameAssignment_1 ) )
            {
            // InternalSwdl.g:742:1: ( ( rule__Element__NameAssignment_1 ) )
            // InternalSwdl.g:743:2: ( rule__Element__NameAssignment_1 )
            {
             before(grammarAccess.getElementAccess().getNameAssignment_1()); 
            // InternalSwdl.g:744:2: ( rule__Element__NameAssignment_1 )
            // InternalSwdl.g:744:3: rule__Element__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Element__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getElementAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group__1__Impl"


    // $ANTLR start "rule__Element__Group__2"
    // InternalSwdl.g:752:1: rule__Element__Group__2 : rule__Element__Group__2__Impl rule__Element__Group__3 ;
    public final void rule__Element__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:756:1: ( rule__Element__Group__2__Impl rule__Element__Group__3 )
            // InternalSwdl.g:757:2: rule__Element__Group__2__Impl rule__Element__Group__3
            {
            pushFollow(FOLLOW_13);
            rule__Element__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Element__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group__2"


    // $ANTLR start "rule__Element__Group__2__Impl"
    // InternalSwdl.g:764:1: rule__Element__Group__2__Impl : ( ':' ) ;
    public final void rule__Element__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:768:1: ( ( ':' ) )
            // InternalSwdl.g:769:1: ( ':' )
            {
            // InternalSwdl.g:769:1: ( ':' )
            // InternalSwdl.g:770:2: ':'
            {
             before(grammarAccess.getElementAccess().getColonKeyword_2()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getElementAccess().getColonKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group__2__Impl"


    // $ANTLR start "rule__Element__Group__3"
    // InternalSwdl.g:779:1: rule__Element__Group__3 : rule__Element__Group__3__Impl ;
    public final void rule__Element__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:783:1: ( rule__Element__Group__3__Impl )
            // InternalSwdl.g:784:2: rule__Element__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Element__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group__3"


    // $ANTLR start "rule__Element__Group__3__Impl"
    // InternalSwdl.g:790:1: rule__Element__Group__3__Impl : ( ( rule__Element__TypeAssignment_3 ) ) ;
    public final void rule__Element__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:794:1: ( ( ( rule__Element__TypeAssignment_3 ) ) )
            // InternalSwdl.g:795:1: ( ( rule__Element__TypeAssignment_3 ) )
            {
            // InternalSwdl.g:795:1: ( ( rule__Element__TypeAssignment_3 ) )
            // InternalSwdl.g:796:2: ( rule__Element__TypeAssignment_3 )
            {
             before(grammarAccess.getElementAccess().getTypeAssignment_3()); 
            // InternalSwdl.g:797:2: ( rule__Element__TypeAssignment_3 )
            // InternalSwdl.g:797:3: rule__Element__TypeAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Element__TypeAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getElementAccess().getTypeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Group__3__Impl"


    // $ANTLR start "rule__Model__ComponentsAssignment_0"
    // InternalSwdl.g:806:1: rule__Model__ComponentsAssignment_0 : ( ruleSWComponent ) ;
    public final void rule__Model__ComponentsAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:810:1: ( ( ruleSWComponent ) )
            // InternalSwdl.g:811:2: ( ruleSWComponent )
            {
            // InternalSwdl.g:811:2: ( ruleSWComponent )
            // InternalSwdl.g:812:3: ruleSWComponent
            {
             before(grammarAccess.getModelAccess().getComponentsSWComponentParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleSWComponent();

            state._fsp--;

             after(grammarAccess.getModelAccess().getComponentsSWComponentParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__ComponentsAssignment_0"


    // $ANTLR start "rule__Model__InterfacesAssignment_1"
    // InternalSwdl.g:821:1: rule__Model__InterfacesAssignment_1 : ( ruleInterface ) ;
    public final void rule__Model__InterfacesAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:825:1: ( ( ruleInterface ) )
            // InternalSwdl.g:826:2: ( ruleInterface )
            {
            // InternalSwdl.g:826:2: ( ruleInterface )
            // InternalSwdl.g:827:3: ruleInterface
            {
             before(grammarAccess.getModelAccess().getInterfacesInterfaceParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleInterface();

            state._fsp--;

             after(grammarAccess.getModelAccess().getInterfacesInterfaceParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__InterfacesAssignment_1"


    // $ANTLR start "rule__SWComponent__NameAssignment_1"
    // InternalSwdl.g:836:1: rule__SWComponent__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__SWComponent__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:840:1: ( ( RULE_ID ) )
            // InternalSwdl.g:841:2: ( RULE_ID )
            {
            // InternalSwdl.g:841:2: ( RULE_ID )
            // InternalSwdl.g:842:3: RULE_ID
            {
             before(grammarAccess.getSWComponentAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getSWComponentAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__NameAssignment_1"


    // $ANTLR start "rule__SWComponent__RequiredPortsAssignment_3"
    // InternalSwdl.g:851:1: rule__SWComponent__RequiredPortsAssignment_3 : ( ruleRequiredPort ) ;
    public final void rule__SWComponent__RequiredPortsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:855:1: ( ( ruleRequiredPort ) )
            // InternalSwdl.g:856:2: ( ruleRequiredPort )
            {
            // InternalSwdl.g:856:2: ( ruleRequiredPort )
            // InternalSwdl.g:857:3: ruleRequiredPort
            {
             before(grammarAccess.getSWComponentAccess().getRequiredPortsRequiredPortParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleRequiredPort();

            state._fsp--;

             after(grammarAccess.getSWComponentAccess().getRequiredPortsRequiredPortParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__RequiredPortsAssignment_3"


    // $ANTLR start "rule__SWComponent__ProvidedPortsAssignment_4"
    // InternalSwdl.g:866:1: rule__SWComponent__ProvidedPortsAssignment_4 : ( ruleProvidedPort ) ;
    public final void rule__SWComponent__ProvidedPortsAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:870:1: ( ( ruleProvidedPort ) )
            // InternalSwdl.g:871:2: ( ruleProvidedPort )
            {
            // InternalSwdl.g:871:2: ( ruleProvidedPort )
            // InternalSwdl.g:872:3: ruleProvidedPort
            {
             before(grammarAccess.getSWComponentAccess().getProvidedPortsProvidedPortParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleProvidedPort();

            state._fsp--;

             after(grammarAccess.getSWComponentAccess().getProvidedPortsProvidedPortParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SWComponent__ProvidedPortsAssignment_4"


    // $ANTLR start "rule__RequiredPort__InterfaceAssignment_1"
    // InternalSwdl.g:881:1: rule__RequiredPort__InterfaceAssignment_1 : ( ( RULE_ID ) ) ;
    public final void rule__RequiredPort__InterfaceAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:885:1: ( ( ( RULE_ID ) ) )
            // InternalSwdl.g:886:2: ( ( RULE_ID ) )
            {
            // InternalSwdl.g:886:2: ( ( RULE_ID ) )
            // InternalSwdl.g:887:3: ( RULE_ID )
            {
             before(grammarAccess.getRequiredPortAccess().getInterfaceInterfaceCrossReference_1_0()); 
            // InternalSwdl.g:888:3: ( RULE_ID )
            // InternalSwdl.g:889:4: RULE_ID
            {
             before(grammarAccess.getRequiredPortAccess().getInterfaceInterfaceIDTerminalRuleCall_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getRequiredPortAccess().getInterfaceInterfaceIDTerminalRuleCall_1_0_1()); 

            }

             after(grammarAccess.getRequiredPortAccess().getInterfaceInterfaceCrossReference_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RequiredPort__InterfaceAssignment_1"


    // $ANTLR start "rule__ProvidedPort__InterfaceAssignment_1"
    // InternalSwdl.g:900:1: rule__ProvidedPort__InterfaceAssignment_1 : ( ( RULE_ID ) ) ;
    public final void rule__ProvidedPort__InterfaceAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:904:1: ( ( ( RULE_ID ) ) )
            // InternalSwdl.g:905:2: ( ( RULE_ID ) )
            {
            // InternalSwdl.g:905:2: ( ( RULE_ID ) )
            // InternalSwdl.g:906:3: ( RULE_ID )
            {
             before(grammarAccess.getProvidedPortAccess().getInterfaceInterfaceCrossReference_1_0()); 
            // InternalSwdl.g:907:3: ( RULE_ID )
            // InternalSwdl.g:908:4: RULE_ID
            {
             before(grammarAccess.getProvidedPortAccess().getInterfaceInterfaceIDTerminalRuleCall_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getProvidedPortAccess().getInterfaceInterfaceIDTerminalRuleCall_1_0_1()); 

            }

             after(grammarAccess.getProvidedPortAccess().getInterfaceInterfaceCrossReference_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ProvidedPort__InterfaceAssignment_1"


    // $ANTLR start "rule__Interface__NameAssignment_1"
    // InternalSwdl.g:919:1: rule__Interface__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Interface__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:923:1: ( ( RULE_ID ) )
            // InternalSwdl.g:924:2: ( RULE_ID )
            {
            // InternalSwdl.g:924:2: ( RULE_ID )
            // InternalSwdl.g:925:3: RULE_ID
            {
             before(grammarAccess.getInterfaceAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getInterfaceAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__NameAssignment_1"


    // $ANTLR start "rule__Interface__ElementsAssignment_3"
    // InternalSwdl.g:934:1: rule__Interface__ElementsAssignment_3 : ( ruleElement ) ;
    public final void rule__Interface__ElementsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:938:1: ( ( ruleElement ) )
            // InternalSwdl.g:939:2: ( ruleElement )
            {
            // InternalSwdl.g:939:2: ( ruleElement )
            // InternalSwdl.g:940:3: ruleElement
            {
             before(grammarAccess.getInterfaceAccess().getElementsElementParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleElement();

            state._fsp--;

             after(grammarAccess.getInterfaceAccess().getElementsElementParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__ElementsAssignment_3"


    // $ANTLR start "rule__Interface__ElementsAssignment_4"
    // InternalSwdl.g:949:1: rule__Interface__ElementsAssignment_4 : ( ruleElement ) ;
    public final void rule__Interface__ElementsAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:953:1: ( ( ruleElement ) )
            // InternalSwdl.g:954:2: ( ruleElement )
            {
            // InternalSwdl.g:954:2: ( ruleElement )
            // InternalSwdl.g:955:3: ruleElement
            {
             before(grammarAccess.getInterfaceAccess().getElementsElementParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleElement();

            state._fsp--;

             after(grammarAccess.getInterfaceAccess().getElementsElementParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__ElementsAssignment_4"


    // $ANTLR start "rule__Element__NameAssignment_1"
    // InternalSwdl.g:964:1: rule__Element__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Element__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:968:1: ( ( RULE_ID ) )
            // InternalSwdl.g:969:2: ( RULE_ID )
            {
            // InternalSwdl.g:969:2: ( RULE_ID )
            // InternalSwdl.g:970:3: RULE_ID
            {
             before(grammarAccess.getElementAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getElementAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__NameAssignment_1"


    // $ANTLR start "rule__Element__TypeAssignment_3"
    // InternalSwdl.g:979:1: rule__Element__TypeAssignment_3 : ( ruleDataType ) ;
    public final void rule__Element__TypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSwdl.g:983:1: ( ( ruleDataType ) )
            // InternalSwdl.g:984:2: ( ruleDataType )
            {
            // InternalSwdl.g:984:2: ( ruleDataType )
            // InternalSwdl.g:985:3: ruleDataType
            {
             before(grammarAccess.getElementAccess().getTypeDataTypeEnumRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleDataType();

            state._fsp--;

             after(grammarAccess.getElementAccess().getTypeDataTypeEnumRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__TypeAssignment_3"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000084002L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000070000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000040002L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000110000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000003800L});

}